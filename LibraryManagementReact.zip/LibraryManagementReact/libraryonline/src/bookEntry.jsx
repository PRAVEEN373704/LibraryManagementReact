import React, { useState } from 'react';
import axios from 'axios';

function BookEntry() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [publicationYear, setPublicationYear] = useState('');
  const [authorId, setAuthorId] = useState('');
  const [categoryId, setCategoryId] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
    const bookData = {
      title,
      description,
      publicationYear,
      authorId,
      categoryId,
    };

    axios.post('https://localhost:7236/Books/api/BookEntry', bookData)
      .then((response) => {
        console.log(response.data);
        alert('Book entry created successfully!');
      })
      .catch((error) => {
        console.error(error);
        alert('Error creating book entry!');
      });
  };

  return (
    <div>
      <h2>Create Book Entry</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Title:
          <input type="text" value={title} onChange={(event) => setTitle(event.target.value)} />
        </label>
        <br />
        <label>
          Description:
          <textarea value={description} onChange={(event) => setDescription(event.target.value)} />
        </label>
        <br />
        <label>
          Publication Year:
          <input type="number" value={publicationYear} onChange={(event) => setPublicationYear(event.target.value)} />
        </label>
        <br />
        <label>
          Author ID:
          <input type="number" value={authorId} onChange={(event) => setAuthorId(event.target.value)} />
        </label>
        <br />
        <label>
          Category ID:
          <input type="number" value={categoryId} onChange={(event) => setCategoryId(event.target.value)} />
        </label>
        <br />
        <button type="submit">Create Book Entry</button>
      </form>
    </div>
  );
}

export default BookEntry;
